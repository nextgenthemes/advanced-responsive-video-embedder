<script type="text/html" id="tmpl-shortcode-ui-media-frame">

	<div class="media-frame-title" style="left: 0;">
		<h1>{{ data.media_frame_title }}</h1>
	</div>

	<div class="media-frame-content" style="left: 0;">
	</div>

	<div class="media-frame-toolbar" style="left: 0;">

	<div class="media-frame-uploader"></div>

</script>
